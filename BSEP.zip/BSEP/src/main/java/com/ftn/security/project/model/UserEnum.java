package com.ftn.security.project.model;

public enum UserEnum {
	REGULAR,ADMIN
}
