package com.ftn.security.project.utils;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.util.UUID;

import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.style.BCStyle;

import com.ftn.security.project.certificate.CertificateModel;

public class CryptoUtil {
	
    public static X500Name generateX500Name(CertificateModel certInfo) {
        return new X500NameBuilder(BCStyle.INSTANCE)
			.addRDN(BCStyle.CN, certInfo.getCommonName())
			.addRDN(BCStyle.SURNAME, certInfo.getSurname())
			.addRDN(BCStyle.GIVENNAME, certInfo.getGivenname())
			.addRDN(BCStyle.O, certInfo.getOrganization())
			.addRDN(BCStyle.OU, certInfo.getOrganizationalUnitName())
			.addRDN(BCStyle.C, certInfo.getCounrtyCode())
			.addRDN(BCStyle.E, certInfo.getEmail())
			.addRDN(BCStyle.UID, UUID.randomUUID().toString())
			.build();
    }
    
    public static KeyPair generateKeyPair() throws NoSuchAlgorithmException, NoSuchProviderException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
		keyGen.initialize(2048, random);
		return keyGen.generateKeyPair();
    }

}