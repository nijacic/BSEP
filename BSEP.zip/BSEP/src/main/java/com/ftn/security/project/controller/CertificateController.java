package com.ftn.security.project.controller;

import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ftn.security.project.certificate.CertificateModelDTO;
import com.ftn.security.project.certificate.CertificateModel;
import com.ftn.security.project.model.User;
import com.ftn.security.project.model.UserEnum;
import com.ftn.security.project.service.CertificateService;

@RestController
@RequestMapping("api/certificates")
public class CertificateController {

	private final CertificateService certificateService;
	private final HttpSession httpSession;
	
	@Autowired
	public CertificateController(CertificateService certificateService, HttpSession httpSession) {
		this.certificateService = certificateService;
		this.httpSession = httpSession;
	}
	
	@GetMapping
	public List<CertificateModelDTO> getCertificates(@RequestParam(value = "type", required = false, defaultValue = "all") String filter) {		
		if (filter.equals("all")) {
			return certificateService.getAll();
		} else if (filter.equals("ca")) {
			return certificateService.getAllCa();
		} else {
			return null;
		}
	}
	
	@GetMapping("{serialNumber}")
	public CertificateModelDTO getCertificate(@PathVariable String serialNumber) {
		return new CertificateModelDTO(certificateService.getOne(serialNumber));
	}

	@GetMapping("download/{serialNumber}")
	public ResponseEntity<?> downloadCertificate(@PathVariable String serialNumber) {
		String certFile = certificateService.download(serialNumber);

		return ResponseEntity.ok()
					.contentType(MediaType.parseMediaType("application/pkix-cert"))
					.contentLength(certFile.length())
					.body(certFile);
	}
	
	@PostMapping
	public CertificateModelDTO postCertificate(@RequestBody @Valid CertificateModel certInfo) {
		User user = (User) httpSession.getAttribute("loggedUser");
		
		if (user == null || user.getUserType() == UserEnum.REGULAR) {
			return null;
		}
		
		if (certInfo.getExpirationDate().before(new Date())) {
			return null;
		}

		return certificateService.add(certInfo);
	}
	
	@PostMapping("{serialNumber}/signable")
	public CertificateModelDTO postCertificateSignable(@PathVariable String serialNumber, @RequestBody CertificateModel certInfo) {
		if (certInfo.getExpirationDate().before(new Date())) {
			return null;
		}
		
		User user = (User) httpSession.getAttribute("loggedUser");
		
		if (user == null || user.getUserType() == UserEnum.REGULAR) {
			return null;
		}
		
		X509Certificate certificate = certificateService.issueCertificate(serialNumber, certInfo, true);
		
		if (certificate == null) {
			return null;
		}
		
		return new CertificateModelDTO(certificate);
	}
	
	@PostMapping("{serialNumber}/end")
	public CertificateModelDTO postCertificateEnd(@PathVariable String serialNumber, @RequestBody CertificateModel certInfo) {
		if (certInfo.getExpirationDate().before(new Date())) {
			return null;
		}
		
		X509Certificate certificate = certificateService.issueCertificate(serialNumber, certInfo, false);
		
		if (certificate == null) {
			return null;
		}
		
		return new CertificateModelDTO(certificate);
	}
	
	@PutMapping("/revoke/{serialNumber}")
	public void revokeCertificate(@PathVariable String serialNumber) {
		User user = (User) httpSession.getAttribute("loggedUser");
		System.out.println(user);
		if (user == null || user.getUserType() == UserEnum.REGULAR) {
			
		}
		
		certificateService.revokeCertificate(serialNumber);
	}
	
	@GetMapping("/check/{serialNumber}")
	public void checkCertificate(@PathVariable String serialNumber) throws Exception {
		boolean check = certificateService.checkValidity(serialNumber);
		System.out.println(check);
		if (!check) {			
				throw new Exception("Nije validan!");		
		}
	}
}
