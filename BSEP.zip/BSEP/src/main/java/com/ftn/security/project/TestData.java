package com.ftn.security.project;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import javax.annotation.PostConstruct;

import org.bouncycastle.operator.OperatorCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ftn.security.project.model.User;
import com.ftn.security.project.model.UserDTO;
import com.ftn.security.project.model.UserEnum;
import com.ftn.security.project.repository.UserReposity;
import com.ftn.security.project.service.UserService;

@Component
public class TestData {
	
	@Autowired
	private UserService accservice;
	
	@Autowired
	private UserReposity accrepository;
	
	@PostConstruct
	private void init() throws NoSuchAlgorithmException, NoSuchProviderException, OperatorCreationException, IOException{
		
		UserDTO au1 = new UserDTO("sone","sone");
		accservice.registerAccount(au1);
		
		UserDTO au3 = new UserDTO("duca","duca");	
		User user = new User(au3.getUsername(), au3.getPassword(), UserEnum.ADMIN);
		accrepository.save(user);
		
	}
}
