package com.ftn.security.project.certificate;

public enum CertificateEnum {
	VALID, EXPIRED, NOTYETVALID, REVOKED
}
