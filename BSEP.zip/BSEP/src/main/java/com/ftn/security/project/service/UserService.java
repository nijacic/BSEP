package com.ftn.security.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ftn.security.project.model.User;
import com.ftn.security.project.model.UserDTO;
import com.ftn.security.project.model.UserEnum;
import com.ftn.security.project.repository.UserReposity;

@Service
public class UserService {

	private final UserReposity accountReposity;
	
	@Autowired
	public UserService(UserReposity accountReposity) {
		this.accountReposity = accountReposity;
	}
	
	public void registerAccount(UserDTO applicationUserDTO) {
		
		User user = new User(applicationUserDTO.getUsername(), applicationUserDTO.getPassword(), UserEnum.REGULAR);
		
		try {			
			accountReposity.save(user);
		} catch(Exception e) {
			System.out.println("Username alredy exists");
		}
	}
	
	public User getAccount(UserDTO userDTO) {
		User user = accountReposity.findByUsername(userDTO.getUsername());
		
		if (user == null) {
			return null;
		}
		
	    if (!userDTO.getPassword().equals(user.getPassword())) {
	    	return null;
	    }
		
		return user;
	}
	
}
