import { bsep } from './bsep.js';


document.getElementById('signInForm').addEventListener('submit', e => {
    e.preventDefault();
    const userInfo = {
        username : document.getElementById('username').value,
        password : document.getElementById('password').value
    }

    bsep.login(userInfo).then(user=>{
        alert('User logged in');
        sessionStorage.setItem("loggedUser", user);
        window.location.href = "index.html";
    }).catch(err => {
        alert('Error!');
        console.log(err);
    });
    
});