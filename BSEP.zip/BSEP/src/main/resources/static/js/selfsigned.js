import { bsep } from './bsep.js';

document.getElementById('certForm').addEventListener('submit', e => {
    e.preventDefault();

    const certInfo = {
        commonName: document.getElementById('cn').value,
        givenname: document.getElementById('surname').value,
        surname: document.getElementById('givenName').value,
        organization: document.getElementById('o').value,
        organizationalUnitName: document.getElementById('ou').value,
        countryCode: document.getElementById('c').value,
        email: document.getElementById('e').value,
        expirationDate: document.getElementById('date').value
    };

    bsep.addCertificate(certInfo).then(res => {
        alert('Certificate is created!')
        console.log(res);
        window.location.href = "index.html";
    }).catch(error => {
        alert('Certificate is NOT created!');
        console.log(error);
    });
});

