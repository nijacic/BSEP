import { bsep } from './bsep.js';

function certTableRow(cert) {
    return `
        <tr>
            <td style="border:#44a1ba solid 1px">${cert.commonName}</td>
            <td style="border:#44a1ba solid 1px">${cert.givenname}</td>
            <td style="border:#44a1ba solid 1px">${cert.surname}</td>
            <td style="border:#44a1ba solid 1px">${cert.organization}</td>
            <td style="border:#44a1ba solid 1px">${cert.organizationalUnitName}</td>
            <td style="border:#44a1ba solid 1px">${cert.countryCode}</td>
            <td style="border:#44a1ba solid 1px">${cert.email}</td>
            <td style="border:#44a1ba solid 1px">
            <a style="background-color:#44a1ba;border:#44a1ba solid 1px" href="/api/certificates/download/${cert.serialNumber}" class="btn btn-success btn-sm">Download</a>
            <button style="background-color:#44a1ba;border:#44a1ba solid 1px" class="btn btn-danger btn-sm" data-serial-number="${cert.serialNumber}">Revoke</button>
                <button style="background-color:#44a1ba;color:white;border:#44a1ba solid 1px" class="btn btn-warning btn-sm" data-serial-number="${cert.serialNumber}">Validity</button>
            </td>
        </tr>
    `;
};

// Check certificate
document.getElementById('certTable').addEventListener('click', e => {
    if (e.target.classList.contains('btn-warning')) {
        fetch('api/certificates/check/' + e.target.dataset.serialNumber, {
        	credentials: 'include'
        })
            .then(res => {
                if (res.ok) {
                    alert('Certificate is valid');
                } else {
                    alert('Certificate is NOT valid');
                }
            });
    }
});

// Revoke certificate
document.getElementById('certTable').addEventListener('click', e => {
    if (e.target.classList.contains('btn-danger')) {
        fetch('api/certificates/revoke/' + e.target.dataset.serialNumber, {
            method: 'put',
            credentials: 'include'
        }).then(res => {
        	if(res.ok){
        		alert('Revoked!');
        	}else{
        		alert("Only administrator can revoke certificate!");
        	}
        });
    }
});

bsep.getCertificates().then(certificates => {
    const table = document.getElementById('certTable');

    for (let cert of certificates) {
        table.innerHTML += certTableRow(cert);
    }
});


